//
//  OCTCommitTreeEntry.h
//  OctoKit
//
//  Created by Josh Abernathy on 9/30/13.
//  Copyright (c) 2013 GitHub. All rights reserved.
//

#import "OCTTreeEntry.h"

// A commit tree entry.
@interface OCTCommitTreeEntry : OCTTreeEntry

@end
