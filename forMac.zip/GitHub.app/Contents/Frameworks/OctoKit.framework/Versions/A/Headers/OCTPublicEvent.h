//
//  OCTPublicEvent.h
//  OctoKit
//
//  Created by Tyler Stromberg on 12/25/14.
//  Copyright (c) 2014 GitHub. All rights reserved.
//

#import "OCTEvent.h"

// A private repository was open sourced. Without a doubt: the best GitHub event.
@interface OCTPublicEvent : OCTEvent

@end
